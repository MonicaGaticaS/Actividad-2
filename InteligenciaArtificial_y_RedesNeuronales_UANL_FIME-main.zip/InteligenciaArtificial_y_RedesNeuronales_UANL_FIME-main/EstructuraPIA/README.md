Ejemplo de estructura de notebook para PIA de la clase Inteligencia Artificial y Redes Neuronales y la clase Inteligencia Artificial. 
