# Clase: Inteligencia Artificial
Temas y ejercicios de la clase "Inteligencia Artificial y Redes Neuronales" para IMTC y la clase "Inteligencia Artificial" para IB de la FIME en la UANL.
