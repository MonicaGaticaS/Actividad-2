These are the dataset options for your final project:

Option 1: https://www.kaggle.com/datasets/uraninjo/augmented-alzheimer-mri-dataset 

Option 2: https://www.kaggle.com/datasets/navoneel/brain-mri-images-for-brain-tumor-detection 

Option 3: https://www.kaggle.com/datasets/mohamedhanyyy/chest-ctscan-images
