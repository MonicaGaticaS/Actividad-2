En esta carpeta se incluye la implementación de diferentes modelos de aprendizaje automático.

Ejemplo de red neuronal básica: 
https://www.tensorflow.org/tutorials/keras/classification?hl=es-419

Ejemplo de red neuronal convolusional:
https://www.tensorflow.org/tutorials/images/cnn?hl=es-419 
